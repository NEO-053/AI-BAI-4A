import tkinter as tk
from tkinter import messagebox
import pygame
import random
import math
from collections import deque
from queue import PriorityQueue
import networkx as nx
import os  


# Constants for maze elements
COIN_VALUES = [5, 10]
POTHOLE_VALUES = [3, 6]
GOAL_VALUES = [1, 2, 3]
BARRIER_VALUE = "BARRIER"

# Probabilities for maze elements
COIN_PROBABILITY = 0.15
POTHOLE_PROBABILITY = 0.1
GOAL_PROBABILITY = 0.01
BARRIER_PROBABILITY = 0.1

def safe_load_image(path, size):
    if os.path.exists(path):
        return pygame.transform.scale(pygame.image.load(path).convert_alpha(), size)
    else:
        surface = pygame.Surface(size)
        surface.fill((200, 200, 200))  # Gray placeholder
        return surface

class Maze:
    def __init__(self, rows, cols, cell_size, flag_coordinates, agent_coordinates):
        self.rows = rows
        self.cols = cols
        self.cell_size = cell_size
        self.grid = [[None for _ in range(cols)] for _ in range(rows)]
        self.coin_positions = []
        self.pothole_positions = []
        self.flag_coordinates = flag_coordinates
        self.coin_img = safe_load_image("coin.png", (self.cell_size, self.cell_size))
        self.pothole_img = safe_load_image("pothole.png", (self.cell_size, self.cell_size))
        self.goal_img = safe_load_image("flag.png", (self.cell_size, self.cell_size))
        self.agent_img = safe_load_image("agent.png", (self.cell_size, self.cell_size))
        self.generate_maze()
        self.avoid_coordinates = []
        self.dead_end_memory = set()
        self.agents = [Agent(x, y, algo) for x, y, algo in agent_coordinates]

    def neighbors(self, cell):
        x, y = cell
        neighbors = []
        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        for dx, dy in directions:
            new_x, new_y = x + dx, y + dy
            if 0 <= new_x < self.cols and 0 <= new_y < self.rows:
                neighbors.append((new_x, new_y))
        return neighbors

    def generate_maze(self):
        for idx, (x, y) in enumerate(self.flag_coordinates):
            self.grid[y][x] = random.choice(GOAL_VALUES)

        for i in range(self.rows):
            for j in range(self.cols):
                if self.grid[i][j] in GOAL_VALUES:
                    continue
                rand = random.random()
                if rand < COIN_PROBABILITY:
                    coin_value = random.choice(COIN_VALUES)
                    self.grid[i][j] = coin_value
                    self.coin_positions.append((i, j))
                elif rand < COIN_PROBABILITY + POTHOLE_PROBABILITY:
                    pothole_value = random.choice(POTHOLE_VALUES)
                    self.grid[i][j] = pothole_value
                    self.pothole_positions.append((i, j))
                elif rand < COIN_PROBABILITY + POTHOLE_PROBABILITY + BARRIER_PROBABILITY:
                    self.grid[i][j] = BARRIER_VALUE
                else:
                    self.grid[i][j] = "Empty"

    def display_maze(self, screen):
        font = pygame.font.SysFont("Arial", 18)

        for i in range(self.rows):
            for j in range(self.cols):
                value = self.grid[i][j]
                cell_rect = pygame.Rect(j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size)
                pygame.draw.rect(screen, (230, 240, 255), cell_rect)  # Default background

                if value in COIN_VALUES:
                    pygame.draw.rect(screen, (255, 215, 0), cell_rect)
                    symbol = font.render("$", True, (0, 0, 0))
                    screen.blit(symbol, (j * self.cell_size + 18, i * self.cell_size + 10))
                elif value in POTHOLE_VALUES:
                    pygame.draw.rect(screen, (139, 69, 19), cell_rect)
                    symbol = font.render("X", True, (255, 255, 255))
                    screen.blit(symbol, (j * self.cell_size + 20, i * self.cell_size + 10))
                elif value in GOAL_VALUES:
                    pygame.draw.rect(screen, (0, 255, 0), cell_rect)
                    symbol = font.render("F", True, (0, 0, 0))
                    screen.blit(symbol, (j * self.cell_size + 20, i * self.cell_size + 10))
                elif value == BARRIER_VALUE:
                    pygame.draw.rect(screen, (100, 100, 100), cell_rect)

        for agent in self.agents:
            pygame.draw.rect(screen, (0, 0, 255), (agent.x * self.cell_size, agent.y * self.cell_size, self.cell_size, self.cell_size))
            symbol = font.render("A", True, (255, 255, 255))
            screen.blit(symbol, (agent.x * self.cell_size + 20, agent.y * self.cell_size + 10))

        for i in range(self.cols):
            pygame.draw.line(screen, (0, 0, 0), (i * self.cell_size, 0), (i * self.cell_size, screen.get_height()))
        for i in range(self.rows):
            pygame.draw.line(screen, (0, 0, 0), (0, i * self.cell_size), (screen.get_width(), i * self.cell_size))

        print("\nDebug Info:")
        print("Coin positions:", self.coin_positions)
        print("Flag positions:", self.flag_coordinates)
        print("Agents:", [(a.x, a.y, a.algorithm) for a in self.agents])



    def check_agent_position(self, agent):
        x, y = agent.x, agent.y
        cell_content = self.grid[y][x]
        if cell_content in COIN_VALUES:
            agent.reward += cell_content
            self.grid[y][x] = "Empty"
            self.coin_positions.remove((y, x))
        elif cell_content in POTHOLE_VALUES:
            agent.reward -= cell_content
            self.avoid_coordinates.append((x, y))
        elif cell_content in GOAL_VALUES:
            agent.reached_goal = True

class Agent:
    def __init__(self, x, y, algorithm):
        self.x = x
        self.y = y
        self.algorithm = algorithm
        self.dfs_i = True
        self.reached_goal = False
        self.reward = 0
        self.visited = set()
        self.frontier = deque()
        self.dfs_list = []

    def mark_dead_end(self, maze, position):
        maze.dead_end_memory.add(position)

    def is_dead_end(self, maze, position):
        return position in maze.dead_end_memory

    def move_randomly(self, maze):
        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        random.shuffle(directions)
        for dx, dy in directions:
            new_x, new_y = self.x + dx, self.y + dy
            if (new_x, new_y) in maze.avoid_coordinates or self.is_dead_end(maze, (new_x, new_y)):
                continue
            if 0 <= new_x < maze.cols and 0 <= new_y < maze.rows:
                if maze.grid[new_y][new_x] != BARRIER_VALUE:
                    self.x, self.y = new_x, new_y
                    return
        self.mark_dead_end(maze, (self.x, self.y))

    def bfs(self, maze):
        self.frontier.append((self.x, self.y))
        self.visited.add((self.x, self.y))
        while self.frontier:
            current = self.frontier.popleft()
            if current in maze.flag_coordinates:
                self.reached_goal = True
                return
            neighbors = [(current[0] + dx, current[1] + dy) for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]]
            for nx, ny in neighbors:
                if 0 <= nx < maze.cols and 0 <= ny < maze.rows and (nx, ny) not in self.visited \
                        and maze.grid[ny][nx] != BARRIER_VALUE and (nx, ny) not in maze.avoid_coordinates \
                        and not self.is_dead_end(maze, (nx, ny)):
                    self.frontier.append((nx, ny))
                    self.visited.add((nx, ny))
            if not self.frontier:
                self.mark_dead_end(maze, current)

    def create_graph(self, N, M):
        G = nx.Graph()
        for i in range(N):
            for j in range(M):
                node = (i, j)
                G.add_node(node)
                if i > 0:
                    G.add_edge(node, (i - 1, j))
                if j > 0:
                    G.add_edge(node, (i, j - 1))
        return G

    def dfs_traversal(self, graph, start_node, maze):
        stack = [start_node]
        visited = set()
        path = []
        while stack:
            node = stack.pop()
            if node not in visited:
                visited.add(node)
                path.append(node)
                if node in maze.flag_coordinates:
                    return path
                neighbors = list(graph.neighbors(node))
                neighbors = [n for n in neighbors if not self.is_dead_end(maze, n)]
                if not neighbors:
                    self.mark_dead_end(maze, node)
                stack.extend(neighbors[::-1])
        for node in path:
            self.mark_dead_end(maze, node)
        return []

    def mov_dfs(self, maze):
        if self.dfs_list:
            x, y = self.dfs_list.pop(0)
            if (x, y) not in maze.avoid_coordinates and not self.is_dead_end(maze, (x, y)):
                self.x, self.y = x, y
                if (self.x, self.y) in maze.flag_coordinates:
                    self.reached_goal = True
            else:
                self.mark_dead_end(maze, (x, y))

    def heuristic(self, p1, p2, heuristic_type):
        if heuristic_type == 1:
            return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])
        elif heuristic_type == 2:
            return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
        elif heuristic_type == 3:
            return max(abs(p1[0] - p2[0]), abs(p1[1] - p2[1]))
        else:
            raise ValueError("Invalid heuristic type.")

    def a_star(self, maze, heuristic_type):
        start = (self.x, self.y)
        goal = maze.flag_coordinates[0]
        frontier = PriorityQueue()
        frontier.put((0, start))
        came_from = {start: None}
        cost_so_far = {start: 0}
        while not frontier.empty():
            _, current = frontier.get()
            if current == goal:
                break
            neighbors = maze.neighbors(current)
            neighbors = [n for n in neighbors if not self.is_dead_end(maze, n)
                         and n not in maze.avoid_coordinates
                         and maze.grid[n[1]][n[0]] != BARRIER_VALUE]
            if not neighbors:
                self.mark_dead_end(maze, current)
                continue
            for next in neighbors:
                new_cost = cost_so_far[current] + 1
                if next not in cost_so_far or new_cost < cost_so_far[next]:
                    cost_so_far[next] = new_cost
                    priority = new_cost + self.heuristic(goal, next, heuristic_type)
                    frontier.put((priority, next))
                    came_from[next] = current
        if current == goal:
            path = []
            while current != start:
                path.append(current)
                current = came_from[current]
            path.append(start)
            path.reverse()
            if len(path) > 1:
                self.x, self.y = path[1]

    def hill_climbing(self, maze, heuristic_type):
        current = (self.x, self.y)
        goal = maze.flag_coordinates[0]
        current_cost = self.heuristic(current, goal, heuristic_type)
        neighbors = maze.neighbors(current)
        next_step = None
        next_cost = current_cost
        for neighbor in neighbors:
            if maze.grid[neighbor[1]][neighbor[0]] != BARRIER_VALUE and not self.is_dead_end(maze, neighbor):
                neighbor_cost = self.heuristic(neighbor, goal, heuristic_type)
                if neighbor_cost < next_cost:
                    next_step = neighbor
                    next_cost = neighbor_cost
        if next_step is not None:
            self.x, self.y = next_step
            current = next_step
        if current == goal:
            self.reached_goal = True

    def move(self, maze, algorithm_type, heuristic_type):
        if self.reached_goal:
            return
        if algorithm_type == 'R':
            self.move_randomly(maze)
        elif algorithm_type == 'B':
            self.bfs(maze)
        elif algorithm_type == 'D':
            if self.dfs_i:
                graph = self.create_graph(maze.rows, maze.cols)
                start_node = (self.x, self.y)
                self.dfs_list = self.dfs_traversal(graph, start_node, maze)
                self.dfs_i = False
            self.mov_dfs(maze)
        elif algorithm_type == 'A':
            self.a_star(maze, heuristic_type)
        elif algorithm_type == 'H':
            self.hill_climbing(maze, heuristic_type)
        maze.check_agent_position(self)

# [Part 3: GUI class FlagAgentGUI will follow in the next update]
import tkinter as tk
from tkinter import messagebox
import pygame
import random
import math
from collections import deque 
from queue import PriorityQueue
import networkx as nx

# Insert the rest of your Maze and Agent classes here without changes
# Only GUI class is rewritten below

class FlagAgentGUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Flag Agent AI Simulator")
        self.master.configure(bg="#f0f8ff")

        self.num_flags = 0
        self.num_agents = 0
        self.flags = []
        self.agents = []
        self.heuristic_type = tk.IntVar(value=1)

        title_label = tk.Label(self.master, text="\U0001F3C1 Flag Agent AI Simulator \U0001F9E0", font=("Arial", 18, "bold"), bg="#f0f8ff", fg="#333")
        title_label.pack(pady=10)

        self.flag_agent_frame = tk.Frame(self.master, bg="#f0f8ff")
        self.flag_agent_frame.pack(pady=10)

        tk.Label(self.flag_agent_frame, text="Number of Flags:", font=("Arial", 12), bg="#f0f8ff").grid(row=0, column=0, padx=10, pady=5, sticky="e")
        self.flag_entry = tk.Entry(self.flag_agent_frame, width=10)
        self.flag_entry.grid(row=0, column=1, pady=5)

        tk.Label(self.flag_agent_frame, text="Number of Agents:", font=("Arial", 12), bg="#f0f8ff").grid(row=1, column=0, padx=10, pady=5, sticky="e")
        self.agent_entry = tk.Entry(self.flag_agent_frame, width=10)
        self.agent_entry.grid(row=1, column=1, pady=5)

        # Heuristic choice
        tk.Label(self.flag_agent_frame, text="Heuristic (A*/Hill):", font=("Arial", 12), bg="#f0f8ff").grid(row=2, column=0, padx=10, pady=5, sticky="e")
        heuristic_menu = tk.OptionMenu(self.flag_agent_frame, self.heuristic_type, 1, 2, 3)
        heuristic_menu.grid(row=2, column=1)

        self.flag_agent_button = tk.Button(self.flag_agent_frame, text="Next \u27A1\ufe0f", bg="#4CAF50", fg="white", font=("Arial", 12), command=self.get_flags_agents)
        self.flag_agent_button.grid(row=3, column=0, columnspan=2, pady=10)

    def get_flags_agents(self):
        self.num_flags = int(self.flag_entry.get())
        self.num_agents = int(self.agent_entry.get())

        self.flag_data = []
        self.agent_data = []

        # Frame for flags
        self.flag_frame = tk.Frame(self.master, bg="#f0f8ff")
        self.flag_frame.pack(pady=10)

        tk.Label(self.flag_frame, text="Flag Coordinates (x, y):", bg="#f0f8ff", font=("Arial", 12, "bold")).grid(row=0, column=0, columnspan=2)

        for i in range(self.num_flags):
            x = tk.Entry(self.flag_frame, width=5)
            y = tk.Entry(self.flag_frame, width=5)
            x.insert(0, str(random.randint(0, 9)))
            y.insert(0, str(random.randint(0, 9)))
            x.grid(row=i+1, column=0, padx=2, pady=2)
            y.grid(row=i+1, column=1, padx=2, pady=2)
            self.flag_data.append((x, y))

        # Frame for agents
        self.agent_frame = tk.Frame(self.master, bg="#f0f8ff")
        self.agent_frame.pack(pady=10)

        tk.Label(self.agent_frame, text="Agent Start (x, y) & Algorithm:", bg="#f0f8ff", font=("Arial", 12, "bold")).grid(row=0, column=0, columnspan=3)

        for i in range(self.num_agents):
            x = tk.Entry(self.agent_frame, width=5)
            y = tk.Entry(self.agent_frame, width=5)
            algo_var = tk.StringVar(self.master)
            algo_var.set("R")
            algo_menu = tk.OptionMenu(self.agent_frame, algo_var, "R", "B", "D", "A", "H")

            x.insert(0, str(random.randint(0, 9)))
            y.insert(0, str(random.randint(0, 9)))

            x.grid(row=i+1, column=0, padx=2, pady=2)
            y.grid(row=i+1, column=1, padx=2, pady=2)
            algo_menu.grid(row=i+1, column=2, padx=2, pady=2)

            self.agent_data.append((x, y, algo_var))

        self.submit_button = tk.Button(self.master, text="Start Simulation", bg="green", fg="white", command=self.submit_data)
        self.submit_button.pack(pady=10)

    def submit_data(self):
        try:
            flag_coordinates = [(int(x.get()), int(y.get())) for x, y in self.flag_data]
            agent_coordinates = [(int(x.get()), int(y.get()), algo.get()) for x, y, algo in self.agent_data]
        except ValueError:
            messagebox.showerror("Error", "Please enter valid integer values for coordinates.")
            return

        self.start_game(flag_coordinates, agent_coordinates)

    def start_game(self, flag_coordinates, agent_coordinates):
        pygame.init()
        rows, cols = 10, 10
        cell_size = 50
        screen_width, screen_height = cols * cell_size, rows * cell_size
        screen = pygame.display.set_mode((screen_width, screen_height))
        pygame.display.set_caption("Maze Game")
        maze = Maze(rows, cols, cell_size, flag_coordinates, agent_coordinates)
        font = pygame.font.Font(None, 20)
        running = True
        clock = pygame.time.Clock()
        heuristic_type = self.heuristic_type.get()
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            screen.fill((240, 248, 255))
            maze.display_maze(screen)
            for i, agent in enumerate(maze.agents):
                if not agent.reached_goal:
                    agent.move(maze, agent.algorithm, heuristic_type)
                info_text = f"Agent {i+1}: {agent.algorithm} | Reward: {agent.reward}"
                info_surf = font.render(info_text, True, (0, 0, 128))
                screen.blit(info_surf, (10, screen_height - 20 * (len(maze.agents) - i)))
            pygame.display.flip()
            clock.tick(2)
        pygame.quit()
        for i, agent in enumerate(maze.agents):
            print(f"Agent {i+1} - Goal Reached with Cost: {agent.reward}")

if __name__ == "__main__":
    root = tk.Tk()
    app = FlagAgentGUI(root)
    root.mainloop()
